list = []
while True :
	x = raw_input("enter the word" " ")
	if x == 'EOF' : 
		break
	else :
		list.append(x)
print list
