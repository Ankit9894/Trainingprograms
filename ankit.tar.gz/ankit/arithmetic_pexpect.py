inp1=int(raw_input("Enter the first input"))
inp2=int(raw_input("Enter the second input"))
sum1= inp1+inp2
print sum1
sub =inp1-inp2
print sub
