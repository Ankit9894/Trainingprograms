rng = input("enter the range")
for i in range(rng) : 
	for j in range(i) : 
		print " * " * j
		

