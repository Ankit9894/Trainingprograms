class Area_rec:
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def area():
		c=a*b
		d=2(a+b)
		print c
		print d
a = Test(10,20)

