from Area_rec import area_rec
e = area_rec(10,20)
e.area()
