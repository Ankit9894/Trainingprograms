import requests as r
g=r.get("http://122.181.186.42:9200")
print g.text
