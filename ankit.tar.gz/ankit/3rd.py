list_input = {'jan':31,'feb':28,'mar':41,'apr':30,'may':31,'june':30,'july':31,'aug':31,'sept':31,'oct':31,'nov':30,'dec':30}
inp = raw_input("enter the month")

print list_input[inp]

