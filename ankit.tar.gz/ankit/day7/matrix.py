class Matrix:
def __init__(self,.a
list1 = []
list2 = []
list3 =[]
inp1 = int(raw_input("ENTER NO OF DIMENTIONS"))
for i in range(inp1):
	row = []
	for j in range(inp1):
		data=input()
		row.append(data)
	list1.append(row)
for i in range(inp1):
	row1 = []
	for j in range(inp1):
		data=input()
		row1.append(data)
	list2.append(row)
print list1
print list2
for i in range(inp1):
	data1=list1[i]+list2[i]
print data1
	#for j in range(inp1):
		#list4=list3.append(data1)
print data1
