days = ( 'sunday','monday','tuesday','wednesday','thursday','friday','saturday' )
input = raw_input("enter the day value")
input = int(input)
print days[input]

