input = raw_input("enter the word")
myword = input.split(" ")
myword1 = " ".join(myword)
output = myword1.reverse()
print output
